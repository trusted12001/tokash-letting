//[Javascript]



$(function () {
    "use strict";   

		//Add text editor
		$("#compose-textarea").wysihtml5();
	
  }); // End of use strict