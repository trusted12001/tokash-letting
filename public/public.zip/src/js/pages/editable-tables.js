//[Javascript]



$(function () {
    "use strict";   
		
	  $('#mainTable').editableTableWidget().numericInputExample().find('td:first').focus();
      $('#example1').editableTableWidget().numericInputExample().find('td:first').focus();
	
  }); // End of use strict