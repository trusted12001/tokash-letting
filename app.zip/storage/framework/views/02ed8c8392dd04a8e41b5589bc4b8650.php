<?php $__env->startSection('content'); ?>
<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Edit User</h3>
  </div>
  <div class="box-body">
    <form method="POST" action="<?php echo e(route('admin.users.update', $user)); ?>">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="form-group">
        <label for="name">Name</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($user->name); ?>" required>
      </div>
      <div class="form-group mt-3">
        <label for="email">Email Address</label>
        <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" required>
      </div>
      <div class="form-group mt-3">
        <label for="roles">Assign Roles</label>
        <select name="roles[]" id="roles" class="form-control" multiple>
          <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($role->name); ?>" <?php echo e($user->hasRole($role->name) ? 'selected' : ''); ?>>
              <?php echo e($role->name); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <button type="submit" class="btn btn-primary mt-4">Update User</button>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.crmi-dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\payGate\resources\views/admin/users/edit.blade.php ENDPATH**/ ?>