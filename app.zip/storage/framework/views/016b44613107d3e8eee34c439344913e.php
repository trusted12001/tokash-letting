<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="">
  <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>">
  <title>CRMi - Dashboard</title>

  <!-- Vendors Style -->
  <link rel="stylesheet" href="<?php echo e(asset('src/css/vendors_css.css')); ?>">
  <!-- Template Style -->
  <link rel="stylesheet" href="<?php echo e(asset('src/css/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('src/css/skin_color.css')); ?>">
</head>
<body class="hold-transition light-skin sidebar-mini theme-primary fixed">
  <div class="wrapper">
    <div id="loader"></div>
    <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <div class="container-full">
        <!-- Main content -->
        <section class="content">
          <?php echo $__env->yieldContent('content'); ?>
        </section>
        <!-- /.content -->
      </div>
    </div>
    <!-- /.content-wrapper -->

    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </div>

  <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\tokash-letting\resources\views/layouts/crmi-dashboard.blade.php ENDPATH**/ ?>