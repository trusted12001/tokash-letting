<footer class="main-footer">
    <div class="pull-right d-none d-sm-inline-block">
      <ul class="nav nav-primary nav-dotted nav-dot-separated justify-content-center justify-content-md-end">
        <li class="nav-item">
          <a class="nav-link" href="https://themeforest.net/item/crmi-bootstrap-admin-dashboard-template/33405709" target="_blank">Purchase Now</a>
        </li>
      </ul>
    </div>
    &copy; <script>document.write(new Date().getFullYear())</script>
    <a href="https://www.multipurposethemes.com/">Multipurpose Themes</a>. All Rights Reserved.
  </footer>
<?php /**PATH C:\xampp\htdocs\payGate\resources\views/partials/footer.blade.php ENDPATH**/ ?>