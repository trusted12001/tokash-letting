<!-- Scripts -->
    <!-- Jquery Start Here -->
    <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
    <!-- Popper Js Start Here -->
    <script src="<?php echo e(asset('assets/js/popper.min.js')); ?>"></script>
    <!-- Bootstrap Js Start Here -->
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>



    <!-- Wow Js Start Here -->
    <script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
    <!-- Owl Carousel Js Start Here -->
    <script src="<?php echo e(asset('assets/vendor/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/jquery.appear.min.js')); ?>"></script>
    <!-- Pop up Js Start Here -->
    <script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <!-- Nice Select Js Start Here -->
    <script src="<?php echo e(asset('assets/js/jquery.nice-select.min.js')); ?>"></script>
    <!-- Parallaxie Js Start Here -->
    <script src="<?php echo e(asset('assets/js/parallaxie.js')); ?>"></script>
    <!-- Tween Js Start Here -->
    <script src="<?php echo e(asset('assets/js/tween-max.js')); ?>"></script>
    <!-- Appear Js Start Here -->
    <script src="<?php echo e(asset('assets/js/appear.min.js')); ?>"></script>
    <!-- Isotope Js Start Here -->
    <script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
    <!-- Imagesloaded Js Start Here -->
    <script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <!-- noUiRangeSlider -->
    <script src="<?php echo e(asset('assets/vendor/noUiSlider/nouislider.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/noUiSlider/wNumb.js')); ?>"></script>
    <!-- Validator Slider -->
    <script src="<?php echo e(asset('assets/js/validator.min.js')); ?>"></script>
    <!-- Pannellum  -->
    <script src="<?php echo e(asset('assets/js/pannellum.js')); ?>"></script>
    <!-- Zoom Image  -->
    <script src="<?php echo e(asset('assets/js/jquery.zoom.min.js')); ?>"></script>

    <!-- Main Js Start Here -->
    <script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>

<?php /**PATH C:\xampp\htdocs\tokash-letting\resources\views/partials/scripts.blade.php ENDPATH**/ ?>