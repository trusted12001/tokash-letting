<!-- Vendor JS -->
<script src="<?php echo e(asset('src/js/vendors.min.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/pages/chat-popup.js')); ?>"></script>
<script src="<?php echo e(asset('assets/icons/feather-icons/feather.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/vendor_components/apexcharts-bundle/dist/apexcharts.js')); ?>"></script>
<!-- CRMi App JS -->
<script src="<?php echo e(asset('src/js/template.js')); ?>"></script>
<script src="<?php echo e(asset('src/js/pages/dashboard.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\payGate\resources\views/partials/scripts.blade.php ENDPATH**/ ?>