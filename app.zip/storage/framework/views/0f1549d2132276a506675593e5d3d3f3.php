<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <h3>Search Results</h3>
    <p>Location: <?php echo e($query); ?></p>
    <p>Duration: <?php echo e($duration); ?></p>

    <!-- Later: loop through actual search results -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokash-letting\resources\views/properties/search-results.blade.php ENDPATH**/ ?>